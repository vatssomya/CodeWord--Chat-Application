import 'package:flutter/material.dart';
import 'chatPage.dart';

class AllMessagesScreen extends StatelessWidget {
  final List<String> users = const [
    "Alice",
    "Bob",
    "ShivamDarshini",
    "Blocked User",
  ];

  const AllMessagesScreen({super.key}); // ✅ Works with constant list

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Messages"),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(20),
        itemCount: users.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(users[index]),
            leading: CircleAvatar(
              backgroundColor: Colors.deepPurpleAccent,
              child: Text(users[index][0]),
            ),
            trailing: Icon(Icons.chat_bubble, color: Colors.deepPurpleAccent),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChatPage(userName: users[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
