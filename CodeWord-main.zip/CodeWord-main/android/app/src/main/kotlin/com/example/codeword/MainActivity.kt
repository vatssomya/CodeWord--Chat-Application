package com.example.codeword

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
